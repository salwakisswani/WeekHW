//
//  ViewModel.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/29/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//
//
//import UIKit
//
//class ViewModel: NSObject {
//
//   @IBOutlet  var episodeList: EpisodesList!
//    var episodes: [NSDictionary]?
//
//
//    func fetchEpisodes(completion: @escaping () -> ()) {
//        episodeList.fetchEpisodes { episodes in
//            self.episodes = episodes
//            completion()
//        }
//    }
//    func numberOfItemsInSection(section: Int) -> Int {
//        return episodes?.count ?? 0
//    }
//    func titleForItemsAtIndexPath(indexPath: IndexPath) -> String {
//        return episodes?[indexPath.row].value(forKeyPath: "name.episodes") as? String ?? ""
//    }
//}
//
