//
//  Show.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/30/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//


import Foundation

struct Show: Decodable {
    
    let name: String
    let runtime: Int
    let episodes: [Episode]
    
    enum CodingKeys: String, CodingKey {
        case name
        case runtime
        case embed = "_embedded"
        case episodes
    }
}

extension Show {
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self
            , forKey: .name)
        self.runtime = try container.decode(Int.self, forKey: .runtime)
        let episodeContainer = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .embed)
        self.episodes = try episodeContainer.decode([Episode].self, forKey: .episodes)
    }
}
