//
//  Settings.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/30/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit


class Settings: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    var viewColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
    var colorNumber:Int!
    @IBOutlet weak var mySwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func switchClicked(_ sender: Any) {
        if mySwitch.isOn {
          viewColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
            myView.backgroundColor = .white
            UserDefaults.standard.set(colorNumber, forKey: "mode")
        }else{
          viewColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                myView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            UserDefaults.standard.set(self.colorNumber, forKey: "mode")
        }
    }
    func  checkForNightMode() {
        if UserDefaults.standard.integer(forKey: "mode") == 1 {
           viewColor = #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
                myView.backgroundColor = viewColor
            mySwitch.isOn = true
        }else{
            viewColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                myView.backgroundColor = viewColor
            mySwitch.isOn = false
        }
    }
}



