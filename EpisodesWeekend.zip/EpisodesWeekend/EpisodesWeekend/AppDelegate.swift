//
//  AppDelegate.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/29/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }
}

