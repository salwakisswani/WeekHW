//
//  BackgroundController.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 7/1/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//
//
//import UIKit
//
//protocol Backgroundable {
//    func changeBackground()
//}
//
//class BackgroundController {
//    static let shared = BackgroundController()
//    private init() {
//        let nightMode = Settings(.nightMode).value
//        if nightMode {
//            currentBackground = .dark
//        }
//        else {
//            currentBackground = .light
//        }
//    }
//    
//    enum Background: String {
//        case light, dark
//    }
//    
//    var BackgroundableViews = [Backgroundable]()
//    
//    static func registerBackgroundable(_ obj: Backgroundable) {
//        shared.BackgroundableViews.append(obj)
//        obj.changeBackground()
//    }
//    
//    
//    var currentBackground: Background {
//        didSet {
//            for view in BackgroundableViews {
//                view.changeBackground()
//            }
//        }
//    }
//    
//    var mainColor: UIColor {
//        switch currentBackground {
//        case .light:
//            return UIColor.white
//        case .dark:
//            return UIColor.black
//        }
//    }
//    var secondaryColor: UIColor {
//        switch currentBackground {
//        case .light:
//            return UIColor(white: 0.95, alpha: 1)
//        case .dark:
//            return UIColor(white: 0.05, alpha: 1)
//        }
//    }
//    var textColor: UIColor {
//        switch currentBackground {
//        case .light:
//            return UIColor.darkText
//        case .dark:
//            return UIColor.lightText
//        }
//    }
//    var tintColor: UIColor {
//        switch currentBackground {
//        case .light:
//            return UIColor.blue
//        case .dark:
//            return UIColor.cyan
//        }
//    }
//    var highlightColor: UIColor {
//        switch currentBackground {
//        case .light:
//            return UIColor.gray.withAlphaComponent(0.5)
//        case .dark:
//            return UIColor.darkGray.withAlphaComponent(0.5)
//        }
//    }
//    var barStyle: UIBarStyle {
//        
//        switch currentBackground {
//        case .light:
//            return .default
//        case .dark:
//            return .black
//        }
//    }
//}
