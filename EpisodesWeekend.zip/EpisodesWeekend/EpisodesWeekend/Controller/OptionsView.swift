//
//  OptionsView.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 7/1/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

class OptionsView: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    let settings = [Setting(.nightMode)]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        BackgroundController.registerBackgroundable(self)
    }
    
    @IBAction func settingHandler(sender: UISwitch) {
        settings[sender.tag].value = sender.isOn
        view.setNeedsDisplay()
    }
}

extension OptionsView: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "optionCell", for: indexPath) as! OptionsTableViewCell
        cell.settingLabel?.text = settings[indexPath.row].description.rawValue
        cell.settingSwitch?.setOn(settings[indexPath.row].value, animated: false)
        cell.settingSwitch?.tag = indexPath.row
        cell.settingSwitch?.addTarget(self, action: #selector(settingHandler), for: .valueChanged)
        
        //Theming
        cell.backgroundColor = BackgroundController.shared.mainColor
        cell.settingLabel?.textColor = BackgroundController.shared.textColor
        cell.selectedBackgroundView = {
            let view = UIView()
            view.backgroundColor = BackgroundController.shared.highlightColor
            return view
        }()
        
        return cell
    }
}

extension OptionsView: Backgroundable {
    func changeBackground() {
        navigationController?.navigationBar.barStyle = BackgroundController.shared.barStyle
        
        self.view.backgroundColor = BackgroundController.shared.mainColor
        self.view.tintColor = BackgroundController.shared.tintColor
        
        tableView.backgroundColor = BackgroundController.shared.mainColor
        
        tableView.reloadData()
        view.setNeedsDisplay()
    }
}
