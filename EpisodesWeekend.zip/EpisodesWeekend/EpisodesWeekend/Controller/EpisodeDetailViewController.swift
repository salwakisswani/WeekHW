//
//  EpisodeDetailViewController.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 7/1/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

class EpisodeDetailViewController: UIViewController {

    @IBOutlet weak var episodeImageView: UIImageView!
    
    @IBOutlet weak var episodeTitleLabel: UILabel!
    
    @IBOutlet weak var episodeSeasonLabel: UILabel!
    @IBOutlet weak var episodeNumberLabel: UILabel!
    @IBOutlet weak var episodeAirdateLabel: UILabel!
    
    @IBOutlet weak var episodeSummaryLabel: UILabel!
    
    var episode: Episode?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       setUpViews()
    }
    
    func setUpViews() {
        if let episode = self.episode {
            episodeTitleLabel.text = episode.name
            episodeSeasonLabel.text = "Season - \(episode.season)"
            episodeNumberLabel.text = "Episode - \(episode.episodeNumber)"
            episodeAirdateLabel.text = "Airdate - \(episode.airdate)"
            episodeSummaryLabel.text = episode.summary
            getImage(for: episode)
        }
    }
    
    func getImage(for episode: Episode) {
        guard let urlString = episode.imageInfo?.originalURL else { return }
        NetworkController().getData(from: urlString) { [weak self] (data, error) in
            if let data = data {
                self?.episodeImageView.image = UIImage(data: data)
            }
        }
    }
}

