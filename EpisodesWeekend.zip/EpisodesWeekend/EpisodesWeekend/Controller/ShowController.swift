//
//  ViewController.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/29/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//
import UIKit

class ShowController {
    
    let networkController: NetworkProtocol
    let showURLString = "https://api.tvmaze.com/shows/1859?embed=seasons&embed=episodes"
    
    init(networkController: NetworkProtocol = NetworkController()) {
        self.networkController = networkController
    }
    
    // MARK: - Create
    
    func getShow(completionHandler: @escaping ([[Episode]]) -> Void) {
        networkController.getData(from: showURLString) { [unowned self] (data, error) in
          guard let data = data,
                  let myShow = try? JSONDecoder().decode(Show.self, from: data)
            else {
                return
            }
            completionHandler(self.sortShowIntoSeasons(show: myShow))
        }
    }
    
    // MARK: - Helper methods
    
    func sortShowIntoSeasons(show: Show) -> [[Episode]] {
        var seasons: [[Episode]] = []
        
        // Step 1: Sort array by season and episode
        let sorted = show.episodes.sorted { (episode1, episode2) -> Bool in
            if episode1.season == episode2.season {
                return episode1.episodeNumber < episode2.episodeNumber
            } else {
                return episode1.season < episode2.season
            
            }
        }
        // step 2: Loop through that array, and start adding episodes to sub arrays
        guard let last = sorted.last else { return [] }
        for _ in 1...last.season {
            seasons.append([])
        }
        for episode in sorted {
            seasons[episode.season - 1].append(episode)
        }
        return seasons
        
    }
}


