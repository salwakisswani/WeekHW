//
//  NetworkController.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/30/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import Foundation

class NetworkController: NetworkProtocol {
    
    func fetchData(from url:String, completionHandler: @escaping (Data?, Error?) -> Void) {
        guard let url = URL(string: url) else{
            return
        }
        URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            completionHandler(data, error)
            }.resume()
    }
}

protocol NetworkProtocol {
    func fetchData(from url: String, completionHandler: @escaping (Data?, Error?) -> Void)
}
