//
//  OptionsTableView.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 7/1/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//



import UIKit

class OptionsTableViewCell: UITableViewCell {

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
