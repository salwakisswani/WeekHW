//
//  EpisodesList.swift
//  EpisodesWeekend
//
//  Created by Salwa Kisswani on 6/29/19.
//  Copyright © 2019 Salwa Kisswani. All rights reserved.
//

import UIKit

//class EpisodesList: NSObject {
//    func fetchEpisodes(completion: @escaping (_ episodes: [NSDictionary]) -> ()) {
//        // fetch the data
//        let urlString = "https://api.tvmaze.com/shows/1859?embed=seasons&embed=episodes"
//        let url = NSURL(string: urlString)!
//
//        let session = URLSession(configuration:
//            URLSessionConfiguration.default)
//        let task = session.dataTask(with: url as URL, completionHandler: {
//            (data, response, error) -> Void in
//            if error != nil {
//            completion()
//
//                 return ()
//            }
//            var jsonError: NSError?
//            if let json = JSONSerialization.JSONObjectWithData(data, options: .AllowFragments, &jsonError) as? NSDictionary {
//                if let epiosdes = json.valueForKeyPath("_embedded") as? [NSDictionary] {
//                    completion(epiosdes)
//                    return
//                }
//            }
//        })
//
//        task.resume()
//
//    }
//}

class EpisodeTableView: UIViewController {
    
    @IBOutlet weak var episodeTableView: UITableView!
    var seasonsArray: [[Episode]] = []
    let showController = ShowController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        episodeTableView.dataSource = self 
        episodeTableView.register(UITableViewCell.self, forCellReuseIdentifier: "episodeCell")
        showController.getShow { (seasons) in
            
            self.seasonsArray = seasons
            DispatchQueue.main.async {
                self.episodeTableView.reloadData()
            }
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let detailViewController = segue.destination as? EpisodeDetailViewController, let index = episodeTableView.indexPathForSelectedRow {
            detailViewController.episode = seasonsArray[index.section][index.row]
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let favoriteItController = segue.destination as? FavoriteItController, let index = episodeTableView.indexPathForSelectedRow {
            favoriteItController.episode = seasonsArray[index.section][index.row]
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Season \(section + 1)"
    }
    
}

extension EpisodeTableView: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return seasonsArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return seasonsArray[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = seasonsArray[indexPath.section][indexPath.row].name
        return cell
    }
    
}
